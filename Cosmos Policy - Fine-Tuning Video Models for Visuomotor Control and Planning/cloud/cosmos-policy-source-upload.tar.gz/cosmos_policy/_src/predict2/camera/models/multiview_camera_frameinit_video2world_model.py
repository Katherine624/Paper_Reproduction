# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Callable, Dict, Tuple

import attrs
import torch
from einops import rearrange
from megatron.core import parallel_state
from torch import Tensor

from cosmos_policy._src.imaginaire.utils import misc
from cosmos_policy._src.imaginaire.utils.context_parallel import (
    broadcast_split_tensor,
    cat_outputs_cp,
)
from cosmos_policy._src.predict2.camera.configs.multiview_camera.conditioner import CameraConditionedCondition
from cosmos_policy._src.predict2.conditioner import DataType
from cosmos_policy._src.predict2.models.video2world_model_rectified_flow import (
    NUM_CONDITIONAL_FRAMES_KEY,
    Video2WorldModelRectifiedFlow,
    Video2WorldModelRectifiedFlowConfig,
)

IS_PREPROCESSED_KEY = "is_preprocessed"


@attrs.define(slots=False)
class CameraConditionedFrameinitVideo2WorldRectifiedFlowConfig(Video2WorldModelRectifiedFlowConfig):
    pass


class CameraConditionedFrameinitVideo2WorldModelRectifiedFlow(Video2WorldModelRectifiedFlow):
    def get_data_and_condition(
        self, data_batch: dict[str, torch.Tensor]
    ) -> Tuple[Tensor, Tensor, CameraConditionedCondition]:
        self._normalize_multicam_video_databatch_inplace(data_batch)
        self._augment_multicam_image_dim_inplace(data_batch)
        is_image_batch = self.is_image_batch(data_batch)

        # Latent cond state
        split_size = data_batch["num_frames"].item()
        raw_state_cond = data_batch[self.input_data_key + "_cond"]
        raw_state_cond_chunks = torch.split(raw_state_cond, split_size_or_sections=split_size, dim=2)
        latent_state_cond_list = []
        for raw_state_cond_chunk in raw_state_cond_chunks:
            latent_state_cond_chunk = self.encode(raw_state_cond_chunk).contiguous().float()
            latent_state_cond_list.append(latent_state_cond_chunk)

        # Latent tgt state
        raw_state_src = data_batch[self.input_data_key]
        raw_state_src_chunks = torch.split(raw_state_src, split_size_or_sections=split_size, dim=2)
        latent_state_src_list = []
        for raw_state_src_chunk in raw_state_src_chunks:
            latent_state_src_chunk = self.encode(raw_state_src_chunk).contiguous().float()
            latent_state_src_list.append(latent_state_src_chunk)

        raw_state = torch.cat(
            (raw_state_src_chunks[0], raw_state_cond_chunks[0], raw_state_src_chunks[1]),
            dim=2,
        )
        latent_state = torch.cat(
            (latent_state_src_list[0], latent_state_cond_list[0], latent_state_src_list[1]),
            dim=2,
        )

        # Condition
        camera_list = torch.chunk(data_batch["camera"], len(latent_state_cond_list) + len(latent_state_src_list), dim=1)
        camera = torch.cat((camera_list[1], camera_list[0], camera_list[2]), dim=1)
        data_batch["camera"] = camera

        condition = self.conditioner(data_batch)
        condition = condition.edit_data_type(DataType.IMAGE if is_image_batch else DataType.VIDEO)
        condition = condition.set_camera_conditioned_video_condition(
            gt_frames=latent_state.to(**self.tensor_kwargs),
            num_conditional_frames=data_batch.get(NUM_CONDITIONAL_FRAMES_KEY, None),
        )

        # torch.distributed.breakpoint()
        return raw_state, latent_state, condition

    def _normalize_multicam_video_databatch_inplace(
        self, data_batch: dict[str, torch.Tensor], input_key: str = None
    ) -> None:
        """
        Normalizes video data in-place on a CUDA device to reduce data loading overhead.
        """
        input_key = self.input_data_key if input_key is None else input_key
        # only handle video batch
        if input_key in data_batch:
            # Check if the data has already been normalized and avoid re-normalizing
            if IS_PREPROCESSED_KEY in data_batch and data_batch[IS_PREPROCESSED_KEY] is True:
                assert torch.is_floating_point(data_batch[input_key]), "Video data is not in float format."
                assert torch.all(
                    (data_batch[input_key] >= -1.0001)
                    & (data_batch[input_key] <= 1.0001)
                    & (data_batch[input_key + "_cond"] >= -1.0001)
                    & (data_batch[input_key + "_cond"] <= 1.0001)
                ), (
                    f"Video data is not in the range [-1, 1]. get data range [{data_batch[input_key].min()}, {data_batch[input_key].max()}]"
                )
            else:
                assert data_batch[input_key].dtype == torch.uint8, "Video data is not in uint8 format."
                data_batch[input_key] = data_batch[input_key].to(**self.tensor_kwargs) / 127.5 - 1.0
                data_batch[input_key + "_cond"] = data_batch[input_key + "_cond"].to(**self.tensor_kwargs) / 127.5 - 1.0
                data_batch[IS_PREPROCESSED_KEY] = True

    def _augment_multicam_image_dim_inplace(self, data_batch: dict[str, torch.Tensor], input_key: str = None) -> None:
        input_key = self.input_image_key if input_key is None else input_key
        if input_key in data_batch:
            # Check if the data has already been augmented and avoid re-augmenting
            if IS_PREPROCESSED_KEY in data_batch and data_batch[IS_PREPROCESSED_KEY] is True:
                assert data_batch[input_key].shape[2] == 1, (
                    f"Image data is claimed be augmented while its shape is {data_batch[input_key].shape}"
                )
                return
            else:
                data_batch[input_key] = rearrange(data_batch[input_key], "b c h w -> b c 1 h w").contiguous()
                data_batch[input_key + "_cond"] = rearrange(
                    data_batch[input_key + "_cond"], "b c h w -> b c 1 h w"
                ).contiguous()
                data_batch[IS_PREPROCESSED_KEY] = True

    @torch.no_grad()
    def get_velocity_fn_from_batch(
        self,
        data_batch: Dict,
        guidance: float = 1.5,
        num_output_video: int = 3,
        is_negative_prompt: bool = False,
    ) -> Callable:
        """
        Generates a callable function `x0_fn` based on the provided data batch and guidance factor.
        """

        if NUM_CONDITIONAL_FRAMES_KEY in data_batch:
            num_conditional_frames = data_batch[NUM_CONDITIONAL_FRAMES_KEY]
        else:
            num_conditional_frames = 1

        camera_list = torch.chunk(data_batch["camera"], num_output_video, dim=1)
        camera = torch.cat((camera_list[1], camera_list[0], camera_list[2]), dim=1)
        data_batch["camera"] = camera

        if is_negative_prompt:
            condition, uncondition = self.conditioner.get_condition_with_negative_prompt(data_batch)
        else:
            condition, uncondition = self.conditioner.get_condition_uncondition(data_batch)

        is_image_batch = self.is_image_batch(data_batch)
        condition = condition.edit_data_type(DataType.IMAGE if is_image_batch else DataType.VIDEO)
        uncondition = uncondition.edit_data_type(DataType.IMAGE if is_image_batch else DataType.VIDEO)

        x0_cond_chunks = torch.chunk(data_batch[self.input_data_key], num_output_video, dim=2)
        x0_cond_list = []
        for x0_cond_chunk in x0_cond_chunks:
            x0_cond = self.encode(x0_cond_chunk).contiguous().float()
            x0_cond_list.append(x0_cond)

        x0 = torch.cat([x0_cond_list[1], x0_cond_list[0], x0_cond_list[2]], dim=2)
        # override condition with inference mode; num_conditional_frames used Here!
        condition = condition.set_camera_conditioned_video_condition(
            gt_frames=x0,
            num_conditional_frames=num_conditional_frames,
        )
        uncondition = uncondition.set_camera_conditioned_video_condition(
            gt_frames=x0,
            num_conditional_frames=num_conditional_frames,
        )

        # torch.distributed.breakpoint()
        _, condition, _, _ = self.broadcast_split_for_model_parallelsim(x0, condition, None, None)
        _, uncondition, _, _ = self.broadcast_split_for_model_parallelsim(x0, uncondition, None, None)

        if parallel_state.is_initialized():
            pass
        else:
            assert not self.net.is_context_parallel_enabled, (
                "parallel_state is not initialized, context parallel should be turned off."
            )

        def velocity_fn(noise: torch.Tensor, noise_x: torch.Tensor, timestep: torch.Tensor) -> torch.Tensor:
            cond_v = self.denoise(noise, noise_x, timestep, condition)
            uncond_v = self.denoise(noise, noise_x, timestep, uncondition)
            velocity_pred = cond_v + guidance * (cond_v - uncond_v)
            return velocity_pred

        return velocity_fn, x0_cond_list

    @torch.no_grad()
    def generate_samples_from_batch(
        self,
        data_batch: Dict,
        guidance: float = 1.5,
        seed: int = 1,
        state_shape: Tuple | None = None,
        n_sample: int | None = None,
        num_output_video: int = 3,
        is_negative_prompt: bool = False,
        num_steps: int = 35,
        shift: float = 5.0,
        **kwargs,
    ) -> torch.Tensor:
        """
        Generate samples from the batch. Based on given batch, it will automatically determine whether to generate image or video samples.
        """

        is_image_batch = self.is_image_batch(data_batch)
        input_key = self.input_image_key if is_image_batch else self.input_data_key
        if n_sample is None:
            n_sample = data_batch[input_key].shape[0]

        if state_shape is None:
            _T, _H, _W = data_batch[input_key].shape[-3:]
            state_shape = [
                self.config.state_ch,
                self.tokenizer.get_latent_num_frames(_T // num_output_video),
                _H // self.tokenizer.spatial_compression_factor,
                _W // self.tokenizer.spatial_compression_factor,
            ]

        velocity_fn, x0_cond_list = self.get_velocity_fn_from_batch(
            data_batch, guidance, num_output_video, is_negative_prompt=is_negative_prompt
        )

        noise_list = []
        for i in range(num_output_video):
            noise = misc.arch_invariant_rand(
                (n_sample,) + tuple(state_shape),
                torch.float32,
                self.tensor_kwargs["device"],
                seed,
            )
            noise[:, :, 0, :, :] = x0_cond_list[i][:, :, 0, :, :]
            noise_list.append(noise)

        noise = torch.cat(noise_list, dim=2)

        seed_g = torch.Generator(device=self.tensor_kwargs["device"])
        seed_g.manual_seed(seed)

        self.sample_scheduler.set_timesteps(num_steps, device=self.tensor_kwargs["device"], shift=shift)

        timesteps = self.sample_scheduler.timesteps

        if self.net.is_context_parallel_enabled:
            noise = broadcast_split_tensor(tensor=noise, seq_dim=2, process_group=self.get_context_parallel_group())
        latents = noise

        for _, t in enumerate(timesteps):
            latent_model_input = latents
            timestep = [t]

            timestep = torch.stack(timestep)

            velocity_pred = velocity_fn(noise, latent_model_input, timestep.unsqueeze(0))
            temp_x0 = self.sample_scheduler.step(
                velocity_pred.unsqueeze(0), t, latents[0].unsqueeze(0), return_dict=False, generator=seed_g
            )[0]
            latents = temp_x0.squeeze(0)

        if self.net.is_context_parallel_enabled:
            latents = cat_outputs_cp(latents, seq_dim=2, cp_group=self.get_context_parallel_group())

        sample_chunks = torch.chunk(latents, num_output_video, dim=2)
        sample_list = [sample_chunks[1], sample_chunks[0], sample_chunks[2]]

        return sample_list
